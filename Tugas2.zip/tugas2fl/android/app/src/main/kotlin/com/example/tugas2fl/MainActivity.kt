package com.example.tugas2fl

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
